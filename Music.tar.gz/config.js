module.exports = {
    prefix: '!',
    nodes: [{
        host: "lavalink.jirayu.net",
        password: "youshallnotpass",
        port: 13592,
        secure: false,
        name: "Main Node"
    }],
    spotify: {
        clientId: "a568b55af1d940aca52ea8fe02f0d93b",
        clientSecret: "e8199f4024fe49c5b22ea9a3dd0c4789"
    },
    botToken: "MTM1MTE1NDcwOTc5MjI5Mjk5Nw.G7rDWc.fbXU2MukpL89tAKHPVj3o4B4D0GvA9ycV4f6JM",
    embedColor: "#0061ff"
};