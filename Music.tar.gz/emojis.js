module.exports = {
    success: "<a:solo_leveling:1351178714431623272>",
    error: "<:emoji2:1351177521642606592>",
    music: "<a:music:1351164511922688081>",
    queue: "<a:quese:1351180983314939906>",
    info: "<:Igrishi:1351167337478230080>",
    time: "<a:time:1351122463349805088>",
    song: "<a:emoji_25:1351175535568621628>",
    volume: "<a:volume:1351122650742657056>",
    pause: "<a:pause:1351183098423021700>",
    play: "<a:play:1351123288738500628>",
    skip: "<:skip:1351123030587473942>",
    previous: "<:previous:1351123032730505291>",
    stop: "<a:stop:1351123424818368512>",
    shuffle: "<:suffle:1350022745986957443>",
    repeat: "<:shuffle:1351123590778454062>",
    loading: "<a:loading:1351123489335148604>"
}; 